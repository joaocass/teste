require('dotenv').config();
const express = require('express');
const path = require('path');
const { MongoClient } = require('mongodb');
const ORIGINAL = require('./seedData');

const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI;
const DB_NAME = process.env.DB_NAME || 'mapa_eleitoral';

if (!MONGODB_URI) {
  console.error('Defina MONGODB_URI no arquivo .env antes de iniciar o servidor.');
  process.exit(1);
}

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

let statesCol;

async function seedIfEmpty() {
  const count = await statesCol.countDocuments();
  if (count === 0) {
    const docs = Object.entries(ORIGINAL).map(([uf, s]) => ({ _id: uf, weight: s.w, polls: [] }));
    await statesCol.insertMany(docs);
    console.log('Seed inicial criado para ' + docs.length + ' estados (sem pesquisas).');
  }
}

function sanitizePoll(body) {
  const lula = Number(body.lula);
  if (Number.isNaN(lula)) return null;
  const oppRaw = Number(body.opp);
  return {
    inst: (body.inst || 'Pesquisa sem nome').toString().slice(0, 120),
    date: /^\d{4}-\d{2}-\d{2}$/.test(body.date) ? body.date : new Date().toISOString().slice(0, 10),
    lula: Math.max(0, Math.min(100, lula)),
    opp: Number.isNaN(oppRaw) ? Math.max(0, Math.min(100, 100 - lula)) : Math.max(0, Math.min(100, oppRaw)),
    cred: Math.max(1, Math.min(5, parseInt(body.cred, 10) || 3))
  };
}

async function start() {
  const client = new MongoClient(MONGODB_URI);
  await client.connect();
  const db = client.db(DB_NAME);
  statesCol = db.collection('states');
  await seedIfEmpty();
  console.log('Conectado ao MongoDB (' + DB_NAME + ').');

  // Lista todos os estados com peso e pesquisas
  app.get('/api/states', async (req, res) => {
    try {
      const docs = await statesCol.find({}).toArray();
      const out = {};
      docs.forEach(d => { out[d._id] = { weight: d.weight, polls: d.polls || [] }; });
      res.json(out);
    } catch (e) {
      res.status(500).json({ error: 'Falha ao ler dados.' });
    }
  });

  // Adiciona uma pesquisa a um estado
  app.post('/api/states/:uf/polls', async (req, res) => {
    try {
      const uf = req.params.uf.toUpperCase();
      const poll = sanitizePoll(req.body || {});
      if (!poll) return res.status(400).json({ error: 'Campo "lula" inválido.' });
      // Nota: no driver oficial do MongoDB (mongodb ^6.x), findOneAndUpdate()
      // retorna o próprio documento atualizado (ou null), e não mais um
      // objeto { value }. Usar "result.value" aqui SEMPRE dava undefined,
      // então o front-end recebia um HTTP 404 e mostrava "Erro ao salvar"
      // mesmo com o $push já persistido no banco — a pesquisa era salva,
      // mas o aviso de erro aparecia do mesmo jeito. Corrigido abaixo.
      const result = await statesCol.findOneAndUpdate(
        { _id: uf },
        { $push: { polls: poll } },
        { returnDocument: 'after' }
      );
      if (!result) return res.status(404).json({ error: 'Estado não encontrado.' });
      res.json(result);
    } catch (e) {
      res.status(500).json({ error: 'Falha ao salvar pesquisa.' });
    }
  });

  // Edita uma pesquisa existente pelo índice
  app.put('/api/states/:uf/polls/:index', async (req, res) => {
    try {
      const uf = req.params.uf.toUpperCase();
      const idx = parseInt(req.params.index, 10);
      const poll = sanitizePoll(req.body || {});
      if (!poll) return res.status(400).json({ error: 'Campo "lula" inválido.' });
      const doc = await statesCol.findOne({ _id: uf });
      if (!doc) return res.status(404).json({ error: 'Estado não encontrado.' });
      const polls = doc.polls || [];
      if (idx < 0 || idx >= polls.length) return res.status(400).json({ error: 'Índice inválido.' });
      polls[idx] = poll;
      await statesCol.updateOne({ _id: uf }, { $set: { polls } });
      res.json({ _id: uf, weight: doc.weight, polls });
    } catch (e) {
      res.status(500).json({ error: 'Falha ao editar pesquisa.' });
    }
  });

  // Remove uma pesquisa pelo índice
  app.delete('/api/states/:uf/polls/:index', async (req, res) => {
    try {
      const uf = req.params.uf.toUpperCase();
      const idx = parseInt(req.params.index, 10);
      const doc = await statesCol.findOne({ _id: uf });
      if (!doc) return res.status(404).json({ error: 'Estado não encontrado.' });
      const polls = doc.polls || [];
      if (idx < 0 || idx >= polls.length) return res.status(400).json({ error: 'Índice inválido.' });
      polls.splice(idx, 1);
      await statesCol.updateOne({ _id: uf }, { $set: { polls } });
      res.json({ _id: uf, weight: doc.weight, polls });
    } catch (e) {
      res.status(500).json({ error: 'Falha ao remover pesquisa.' });
    }
  });

  // Limpa todas as pesquisas de todos os estados
  app.post('/api/reset', async (req, res) => {
    try {
      await statesCol.updateMany({}, { $set: { polls: [] } });
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: 'Falha ao limpar dados.' });
    }
  });

  app.listen(PORT, () => console.log('Servidor rodando em http://localhost:' + PORT));
}

start().catch(err => {
  console.error('Erro ao iniciar o servidor:', err.message);
  process.exit(1);
});
