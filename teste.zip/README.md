# Observatório das Pesquisas (2º turno 2026)

Agregador independente de pesquisas. Node.js (sem Express) + MongoDB + HTML/CSS/JS puro. Gráfico SVG próprio com LOESS real (`public/stats.js`).

## Executar
1. Tenha Node 18+ e um MongoDB rodando (ex.: `docker run -d -p 27017:27017 mongo:7`).
2. `npm install`
3. `npm start` → http://localhost:3000
Variáveis: `MONGODB_URI`, `MONGODB_DB`, `PORT`, `SITE_NAME` (nome do site), `NO_FILE_FALLBACK=1` (falha se o Mongo estiver fora; sem isso, cai em `data/polls.json` só para desenvolvimento).
Testes: `npm test` (cálculos, LOESS, API).

## Estrutura
- `public/stats.js` votos válidos, validação, ponderação, agregação, LOESS (isolado/testado)
- `lib/store.js` persistência MongoDB (com fallback em arquivo) · `server.js` API REST + estáticos
- `public/index.html|style.css|app.js` interface · `test/` testes

## Limitações conhecidas
- O driver MongoDB **não foi testado contra um Mongo real** (ambiente sem rede); a API foi testada no modo arquivo.
- Não implementados: exportação PNG, média móvel, desfazer, paginação da tabela, IndexedDB, filtros avançados (margem, amostra, estado, data de divulgação), skeletons, prévia detalhada de importação (há confirmação simples + relatório de erros), testes de interface.
- Suavização: grau 1, span fixo por nível (30/55/85%), sem intervalo de confiança.
- Sem autenticação: qualquer um com acesso ao servidor edita os dados.
- Os dados de demonstração são fictícios e marcados "DEMO".
