let DATA = {};
let selectedUF = null;
let editingIndex = null;   // índice da pesquisa em edição (null = modo "adicionar nova")
let method = 'ponderada';   // 'ponderada' (credibilidade+recência) | 'simples' (média pura) | 'ajustada' (+ efeito de casa)
let mapMode = 'atual';      // 'atual' (intenção de voto) | 'variacao' (Δ p.p. vs 2022)
const ELECTION_DAY = '2026-10-25'; // 2º turno das eleições de 2026 — horizonte das projeções

/* ---------- Parâmetros do agregador estatístico -----------------------
   Valores usados pelos mesmos princípios que agregadores de pesquisa reais
   (FiveThirtyEight, RealClearPolitics, Split Ticket etc.) usam: ponderação
   por recência/credibilidade, correção de "efeito de casa" por instituto,
   e intervalo de confiança a partir da dispersão entre pesquisas. */
const STALE_DAYS_THRESHOLD = 45; // pesquisa mais recente do estado com mais dias que isso => "dado desatualizado"
const DECISIVE_MARGIN = 5;       // |Lula - Flávio| abaixo disso => "estado decisivo" (corrida apertada)
const Z95 = 1.96;                // valor crítico normal para intervalo de confiança de 95%
let HOUSE_EFFECTS = {};          // cache: {instituto: viés médio em p.p. frente ao consenso}, recalculado a cada refresh()

/* ---------- Decaimento por recência ----------------------------------
   Quanto mais antiga a pesquisa, menor o peso dela na média. Usamos uma
   meia-vida: a cada RECENCY_HALF_LIFE_DAYS dias, o peso da pesquisa cai
   pela metade. Um piso (RECENCY_FLOOR) evita que pesquisas muito antigas
   sejam descartadas por completo — elas ainda contam como um sinal fraco. */
const RECENCY_HALF_LIFE_DAYS = 120;
const RECENCY_FLOOR = 0.12;

function daysBetween(iso, ref) {
  const a = new Date(iso + 'T00:00:00');
  const b = ref || new Date();
  return Math.max(0, Math.round((b - a) / 86400000));
}
function recencyWeight(iso) {
  const d = daysBetween(iso, new Date());
  const w = Math.pow(0.5, d / RECENCY_HALF_LIFE_DAYS);
  return Math.max(RECENCY_FLOOR, w);
}

function todayISO(){ return new Date().toISOString().slice(0,10); }
function fmtDate(d){ if(!d) return '—'; const [y,m,dd]=d.split('-'); return dd+'/'+m+'/'+y; }
function fmtPP(v){
  const sign = v > 0.05 ? '+' : (v < -0.05 ? '' : '±');
  return sign + v.toFixed(1) + ' p.p.';
}
/* ---------- Ícones (sprite SVG único, ver index.html) ------------------- */
function icon(name, cls){ return '<svg class="icon'+(cls?(' '+cls):'')+'" aria-hidden="true" focusable="false"><use href="#i-'+name+'"></use></svg>'; }
function trendIcon(dir){ return icon(dir==='up'?'trend-up':dir==='down'?'trend-down':'trend-flat','filled'); }
function signalIcon(tier){
  const bars = tier==='alta'?3 : tier==='moderada'?2 : 1;
  const rects = [
    '<rect x="3" y="14" width="4" height="7" rx="1"/>',
    '<rect x="10" y="9" width="4" height="12" rx="1"/>',
    '<rect x="17" y="3" width="4" height="18" rx="1"/>'
  ].map((r,i)=> i<bars ? r : r.replace('/>',' class="dim"/>')).join('');
  return '<svg class="icon signal" aria-hidden="true" viewBox="0 0 24 24">'+rects+'</svg>';
}
function ppClass(v){ return v > 0.05 ? 'up' : (v < -0.05 ? 'down' : 'flat'); }
function ppArrow(v){ return trendIcon(v > 0.05 ? 'up' : (v < -0.05 ? 'down' : 'flat')); }

function setSync(state, msg){
  const b=document.getElementById('syncBadge'), l=document.getElementById('syncLabel');
  b.classList.remove('on','err');
  if(state==='on'){ b.classList.add('on'); l.textContent='Conectado ao MongoDB'; }
  else if(state==='err'){ b.classList.add('err'); l.textContent=msg||'Erro de conexão'; }
  else { l.textContent='Conectando ao MongoDB…'; }
}

async function fetchStates(){
  const res = await fetch('/api/states');
  if(!res.ok) throw new Error('HTTP '+res.status);
  return res.json();
}
async function addPoll(uf, poll){
  const res = await fetch('/api/states/'+uf+'/polls', {
    method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(poll)
  });
  if(!res.ok) throw new Error('HTTP '+res.status);
  return res.json();
}
async function editPoll(uf, index, poll){
  const res = await fetch('/api/states/'+uf+'/polls/'+index, {
    method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(poll)
  });
  if(!res.ok) throw new Error('HTTP '+res.status);
  return res.json();
}
async function removePoll(uf, index){
  const res = await fetch('/api/states/'+uf+'/polls/'+index, { method:'DELETE' });
  if(!res.ok) throw new Error('HTTP '+res.status);
  return res.json();
}
async function resetAll(){
  const res = await fetch('/api/reset', { method:'POST' });
  if(!res.ok) throw new Error('HTTP '+res.status);
  return res.json();
}

/* ---------- Efeito de casa (house effects) -----------------------------
   Técnica padrão de agregadores de pesquisa (FiveThirtyEight, Split
   Ticket, RealClearPolitics): para cada pesquisa de um instituto num
   estado, compara-se o resultado dela com a média ponderada das
   pesquisas de TODOS OS OUTROS institutos naquele mesmo estado. A
   diferença média (ponderada por credibilidade × recência) é o "viés de
   casa" do instituto — o quanto ele tende a ficar sistematicamente acima
   ou abaixo do consenso. Só é calculável quando há pelo menos 2
   institutos diferentes pesquisando o mesmo estado. */
function houseEffects(){
  const acc = {}; // instituto -> {sumW, sumDevW}
  for(const uf in DATA){
    const polls = ((DATA[uf] && DATA[uf].polls) || []).filter(p=>p.date);
    if(polls.length < 2) continue;
    polls.forEach(p=>{
      const others = polls.filter(o=>o.inst!==p.inst);
      if(!others.length) return; // instituto sozinho no estado: sem consenso alheio pra comparar
      let sw=0, sl=0;
      others.forEach(o=>{ const w=o.cred*recencyWeight(o.date); sw+=w; sl+=o.lula*w; });
      if(!sw) return;
      const otherAvg = sl/sw;
      const w = p.cred*recencyWeight(p.date);
      const a = acc[p.inst] || (acc[p.inst]={sumW:0,sumDevW:0,n:0});
      a.sumW += w; a.sumDevW += (p.lula-otherAvg)*w; a.n++;
    });
  }
  const out = {};
  for(const inst in acc){ out[inst] = acc[inst].sumW ? acc[inst].sumDevW/acc[inst].sumW : 0; }
  return out;
}

/* ---------- Médias por estado ---------- */
function stateAvg(uf){
  const polls = (DATA[uf] && DATA[uf].polls) || [];
  if(!polls.length) return {lula:50, opp:50, has:false, effN:0};
  if(method==='simples'){
    const l = polls.reduce((a,p)=>a+p.lula,0)/polls.length;
    return {lula:l, opp:100-l, has:true, effN:polls.length};
  }
  let sumW=0, sumL=0;
  polls.forEach(p=>{
    const rw = p.date ? recencyWeight(p.date) : 1;
    const w = p.cred * rw;
    let val = p.lula;
    if(method==='ajustada') val -= (HOUSE_EFFECTS[p.inst] || 0); // remove o viés sistemático do instituto
    sumW += w; sumL += val * w;
  });
  const l = sumW ? clampPct(sumL/sumW) : 50;
  return {lula:l, opp:100-l, has:true, effN: polls.length};
}

/* ---------- Dispersão, intervalo de confiança e "confiança da amostra" -
   Sem acesso ao tamanho amostral de cada pesquisa, a forma honesta de
   estimar incerteza é tratar cada pesquisa do estado como um ponto de uma
   meta-amostra (a mesma lógica de meta-análise de efeitos aleatórios):
   calcula-se o desvio-padrão ponderado das pesquisas em torno da média do
   estado, e o erro-padrão da média é esse desvio dividido pela raiz do
   número de pesquisas. O IC95% = ±1,96×erro-padrão. Isso é uma medida de
   QUANTO AS PESQUISAS DISCORDAM ENTRE SI, não de erro amostral de uma
   pesquisa individual — mas é exatamente o que um agregador consegue
   estimar a partir dos dados que tem. */
function stateDispersion(uf){
  const polls = ((DATA[uf] && DATA[uf].polls) || []);
  const n = polls.length;
  if(n===0) return {n:0, tier:'sem-dados', divergence:null, moe:null, stdDev:null};
  if(n===1) return {n:1, tier:'preliminar', divergence:0, moe:null, stdDev:null};
  const vals = polls.map(p=>p.lula);
  const divergence = Math.max(...vals) - Math.min(...vals);
  const avg = stateAvg(uf).lula;
  let sumW=0, sumWD=0;
  polls.forEach(p=>{
    const w = p.cred*(p.date?recencyWeight(p.date):1);
    sumW += w; sumWD += w*(p.lula-avg)*(p.lula-avg);
  });
  const variance = sumW ? sumWD/sumW : 0;
  const stdDev = Math.sqrt(variance);
  const sem = stdDev / Math.sqrt(n);
  const moe = Z95 * sem;
  const tier = n>=8 ? 'alta' : n>=4 ? 'moderada' : 'baixa';
  return {n, tier, divergence, moe, stdDev};
}
const TIER_LABEL = {'sem-dados':'Sem pesquisas','preliminar':'Dado preliminar (1 pesquisa)','baixa':'Confiança baixa','moderada':'Confiança moderada','alta':'Confiança alta'};

/* ---------- Tendência simples: primeira pesquisa cadastrada do estado
   frente à mais recente (independente da regressão usada na projeção
   nacional — aqui é só um "de onde veio, pra onde foi"). */
function stateTrendSimple(uf){
  const polls = statePollsSorted(uf);
  if(polls.length < 2) return null;
  const from = polls[0], to = polls[polls.length-1];
  const delta = to.lula - from.lula;
  return {delta, from, to, dir: delta>0.5?'up':delta<-0.5?'down':'flat'};
}

/* ---------- Selo de dado desatualizado ---------- */
function stateStale(uf){
  const polls = statePollsSorted(uf);
  if(!polls.length) return {stale:false, days:null};
  const last = polls[polls.length-1].date;
  const days = daysBetween(last, new Date());
  return {stale: days > STALE_DAYS_THRESHOLD, days, lastDate:last};
}
/* Variação em pontos percentuais de Lula frente ao resultado oficial de 2022 do estado. */
function stateDelta(uf){
  const base = BASELINE_2022[uf];
  const avg = stateAvg(uf);
  if(!base || !avg.has) return null;
  return avg.lula - base.lula;
}

function mix(hexA,hexB,t){
  const a=hexA.match(/\w\w/g).map(x=>parseInt(x,16));
  const b=hexB.match(/\w\w/g).map(x=>parseInt(x,16));
  const c=a.map((v,i)=>Math.round(v+(b[i]-v)*t));
  return '#'+c.map(v=>v.toString(16).padStart(2,'0')).join('');
}
function colorFor(lula){
  const margin=lula-50;
  const t=Math.max(-1,Math.min(1,margin/25));
  return t>=0 ? mix('#f2ead9','#7c2a20',t) : mix('#f2ead9','#253d50',-t);
}
function colorForDelta(delta){
  // Escala divergente: verde = Lula avançou vs 2022, dourado = recuou.
  const t = Math.max(-1, Math.min(1, delta/12));
  return t>=0 ? mix('#f2ead9','#2c6b46',t) : mix('#f2ead9','#8c6205',-t);
}

/* ---------- Curva suave (Catmull-Rom -> Bézier cúbica) -----------------
   Conecta os mesmos pontos de dados com curvas em vez de segmentos retos
   — o traço fica bem mais legível quando há muitos pontos, no mesmo
   estilo usado por agregadores de pesquisa profissionais (Economist,
   FiveThirtyEight etc.), sem inventar nenhum valor: a curva ainda passa
   exatamente por cada ponto real. Com 1-2 pontos cai para reta simples. */
function smoothLinePath(pts){
  const n = pts.length;
  if(n===0) return '';
  if(n===1) return 'M'+pts[0].x.toFixed(1)+','+pts[0].y.toFixed(1);
  if(n===2) return 'M'+pts[0].x.toFixed(1)+','+pts[0].y.toFixed(1)+' L'+pts[1].x.toFixed(1)+','+pts[1].y.toFixed(1);
  let d = 'M'+pts[0].x.toFixed(1)+','+pts[0].y.toFixed(1)+' ';
  for(let i=0;i<n-1;i++){
    const p0 = pts[i===0?0:i-1], p1 = pts[i], p2 = pts[i+1], p3 = pts[i+2<n?i+2:n-1];
    const c1x = p1.x + (p2.x - p0.x)/6, c1y = p1.y + (p2.y - p0.y)/6;
    const c2x = p2.x - (p3.x - p1.x)/6, c2y = p2.y - (p3.y - p1.y)/6;
    d += 'C'+c1x.toFixed(1)+','+c1y.toFixed(1)+' '+c2x.toFixed(1)+','+c2y.toFixed(1)+' '+p2.x.toFixed(1)+','+p2.y.toFixed(1)+' ';
  }
  return d;
}
/* Mesma spline, mas fechando no eixo da base para servir de área preenchida. */
function smoothAreaPath(pts, baseY){
  if(!pts.length) return '';
  const line = smoothLinePath(pts);
  const first = pts[0], last = pts[pts.length-1];
  return line+' L'+last.x.toFixed(1)+','+baseY+' L'+first.x.toFixed(1)+','+baseY+' Z';
}

/* ---------- Exportação de gráficos SVG como PNG -------------------------
   Não depende de nenhuma lib externa: clona o SVG, "achata" o estilo de
   cada elemento (resolve as variáveis CSS/():root para a cor final que
   está sendo exibida na tela, via getComputedStyle) para que o desenho
   fique idêntico mesmo fora do documento, desenha num <canvas> em alta
   resolução (2.5x) com título/subtítulo/legenda no estilo de um relatório
   de agregador de pesquisas, e dispara o download. */
const EXPORT_STYLE_PROPS = ['fill','stroke','stroke-width','stroke-dasharray','stroke-linecap','stroke-linejoin','stroke-opacity','fill-opacity','opacity','font-family','font-size','font-weight','font-style','text-anchor','letter-spacing'];
function inlineComputedStyles(srcEl, dstEl){
  if(srcEl.nodeType===1){
    const cs = getComputedStyle(srcEl);
    let style='';
    EXPORT_STYLE_PROPS.forEach(p=>{ const v=cs.getPropertyValue(p); if(v) style += p+':'+v+';'; });
    if(style) dstEl.setAttribute('style', style);
  }
  const a = srcEl.children, b = dstEl.children;
  for(let i=0;i<a.length;i++) inlineComputedStyles(a[i], b[i]);
}
function svgToImage(svgEl, w, h, bg){
  const clone = svgEl.cloneNode(true);
  inlineComputedStyles(svgEl, clone);
  clone.setAttribute('width', w);
  clone.setAttribute('height', h);
  clone.setAttribute('xmlns','http://www.w3.org/2000/svg');
  const bgRect = document.createElementNS('http://www.w3.org/2000/svg','rect');
  bgRect.setAttribute('x','0'); bgRect.setAttribute('y','0');
  bgRect.setAttribute('width', w); bgRect.setAttribute('height', h);
  bgRect.setAttribute('fill', bg);
  clone.insertBefore(bgRect, clone.firstChild);
  const xml = new XMLSerializer().serializeToString(clone);
  const uri = 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(xml);
  const img = new Image();
  return new Promise((resolve,reject)=>{ img.onload=()=>resolve(img); img.onerror=reject; img.src=uri; });
}
async function exportChartPNG(svgId, filename, opts){
  opts = opts || {};
  const svgEl = document.getElementById(svgId);
  if(!svgEl) return;
  const btn = opts.button;
  const btnLabel = btn ? btn.innerHTML : null;
  try{
    if(btn){ btn.disabled = true; btn.innerHTML = 'Gerando…'; }
    const vb = (svgEl.getAttribute('viewBox')||'').split(/\s+/).map(Number);
    const w = vb.length===4 ? vb[2] : svgEl.clientWidth;
    const h = vb.length===4 ? vb[3] : svgEl.clientHeight;
    const bg = opts.bg || '#fffdf8';
    const headH = opts.title ? 66 : 0;
    const legendH = (opts.legend && opts.legend.length) ? 34 : 0;
    const footH = 26;
    const totalH = headH + h + legendH + footH;
    const scale = opts.scale || 2.5;
    const img = await svgToImage(svgEl, w, h, bg);
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(w*scale);
    canvas.height = Math.round(totalH*scale);
    const ctx = canvas.getContext('2d');
    ctx.scale(scale, scale);
    ctx.fillStyle = bg;
    ctx.fillRect(0,0,w,totalH);
    let y = 0;
    if(opts.title){
      ctx.fillStyle = '#241f18';
      ctx.font = '700 17px Inter, sans-serif';
      ctx.textBaseline = 'top';
      ctx.fillText(opts.title, 16, 14);
      if(opts.subtitle){
        ctx.fillStyle = '#6f6553';
        ctx.font = '400 11.5px Inter, sans-serif';
        wrapCanvasText(ctx, opts.subtitle, 16, 36, w-32, 14);
      }
      ctx.strokeStyle = '#e3dac2'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, headH-1); ctx.lineTo(w, headH-1); ctx.stroke();
      y = headH;
    }
    ctx.drawImage(img, 0, y, w, h);
    y += h;
    if(legendH){
      let lx = 16;
      ctx.font = '600 11px Inter, sans-serif';
      ctx.textBaseline = 'middle';
      opts.legend.forEach(item=>{
        ctx.fillStyle = item.color;
        ctx.beginPath(); ctx.roundRect ? ctx.roundRect(lx, y+13, 11, 11, 3) : ctx.rect(lx, y+13, 11, 11); ctx.fill();
        ctx.fillStyle = '#241f18';
        ctx.fillText(item.label, lx+16, y+19);
        lx += 16 + ctx.measureText(item.label).width + 22;
      });
      y += legendH;
    }
    ctx.strokeStyle = '#e3dac2'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, y+1); ctx.lineTo(w, y+1); ctx.stroke();
    ctx.fillStyle = '#948a75';
    ctx.font = '400 10px Inter, sans-serif';
    ctx.textBaseline = 'middle';
    ctx.fillText(opts.watermark || 'Painel independente de acompanhamento eleitoral · não oficial · gerado em '+fmtDate(todayISO()), 16, y+13);
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
  } catch(err){
    console.error(err);
    alert('Não foi possível gerar o PNG: '+err.message);
  } finally {
    if(btn){ btn.disabled = false; btn.innerHTML = btnLabel; }
  }
}
function wrapCanvasText(ctx, text, x, y, maxWidth, lineHeight){
  const words = text.split(' ');
  let line = '', ly = y;
  for(const w of words){
    const test = line + w + ' ';
    if(ctx.measureText(test).width > maxWidth && line){
      ctx.fillText(line, x, ly); line = w+' '; ly += lineHeight;
    } else line = test;
  }
  if(line) ctx.fillText(line, x, ly);
}

function buildSVG(){
  const svg=document.getElementById('brmap');
  svg.innerHTML='';
  for(const uf in PATHS){
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    p.setAttribute('d',PATHS[uf]);
    p.setAttribute('class','state');
    p.setAttribute('id','st-'+uf);
    p.addEventListener('click',()=>{ selectTab('map'); openPanel(uf); });
    const t=document.createElementNS('http://www.w3.org/2000/svg','title');
    t.textContent=NAMES[uf];
    p.appendChild(t);
    svg.appendChild(p);
  }
}
/* Watermark decorativo no cabeçalho: reaproveita os MESMOS contornos dos
   estados usados no mapa interativo (nenhum dado novo), só que desenhados
   em conjunto, bem sutis, como textura de fundo — reforça a identidade
   "mapa" do produto em vez de um ícone genérico. */
function buildWatermark(){
  const svg=document.getElementById('brmap-watermark');
  if(!svg) return;
  for(const uf in PATHS){
    const p=document.createElementNS('http://www.w3.org/2000/svg','path');
    p.setAttribute('d',PATHS[uf]);
    svg.appendChild(p);
  }
}
function renderMap(){
  for(const uf in PATHS){
    const avg=stateAvg(uf);
    const el=document.getElementById('st-'+uf);
    if(mapMode==='variacao'){
      const d = stateDelta(uf);
      el.setAttribute('fill', d===null ? 'var(--border-strong,#cdbf9c)' : colorForDelta(d));
      const titleEl = el.querySelector('title');
      if(titleEl) titleEl.textContent = NAMES[uf] + (d===null ? ' — sem dados' : ' — ' + fmtPP(d) + ' vs 2022');
    } else {
      el.setAttribute('fill', avg.has ? colorFor(avg.lula) : 'var(--border-strong,#cdbf9c)');
      const titleEl = el.querySelector('title');
      if(titleEl) titleEl.textContent = NAMES[uf];
    }
    el.classList.toggle('sel', uf===selectedUF);
  }
  document.getElementById('legend').innerHTML = mapMode==='variacao'
    ? '<span><span class="swatch" style="background:#8c6205"></span>Recuo de Lula vs 2022</span>'+
      '<span><span class="swatch" style="background:var(--paper-alt);border:1px solid var(--border)"></span>Sem dados / estável</span>'+
      '<span><span class="swatch" style="background:#2c6b46"></span>Avanço de Lula vs 2022</span>'
    : '<span><span class="swatch" style="background:var(--opp)"></span>Flávio à frente</span>'+
      '<span><span class="swatch" style="background:var(--paper-alt);border:1px solid var(--border)"></span>Sem dados / empate</span>'+
      '<span><span class="swatch" style="background:var(--lula)"></span>Lula à frente</span>';
}
function renderBar(){
  let sumL=0,sumO=0,sumW=0;
  for(const uf in DATA){
    const avg=stateAvg(uf);
    if(!avg.has) continue;
    const w=DATA[uf].weight;
    sumL+=avg.lula*w; sumO+=avg.opp*w; sumW+=w;
  }
  const lead=document.getElementById('lead');
  if(sumW===0){
    document.getElementById('seg-lula').style.width='50%';
    document.getElementById('seg-opp').style.width='50%';
    document.getElementById('seg-lula').textContent='';
    document.getElementById('seg-opp').textContent='';
    lead.innerHTML='Adicione pesquisas para calcular a média nacional.';
    return;
  }
  const lula=sumL/sumW, opp=sumO/sumW;
  document.getElementById('seg-lula').style.width=lula+'%';
  document.getElementById('seg-opp').style.width=opp+'%';
  document.getElementById('seg-lula').textContent=lula.toFixed(1)+'%';
  document.getElementById('seg-opp').textContent=opp.toFixed(1)+'%';
  const cov = (sumW*100).toFixed(0);
  if(lula>opp) lead.innerHTML='<b>Lula</b> venceria com '+lula.toFixed(1)+'% x '+opp.toFixed(1)+'% <span class="muted">('+cov+'% do peso nacional coberto)</span>';
  else if(opp>lula) lead.innerHTML='<b>Flávio</b> venceria com '+opp.toFixed(1)+'% x '+lula.toFixed(1)+'% <span class="muted">('+cov+'% do peso nacional coberto)</span>';
  else lead.textContent='Empate técnico';
}
function renderRank(){
  const rows=[];
  for(const uf in DATA){ rows.push({uf, avg: stateAvg(uf), delta: stateDelta(uf), stale: stateStale(uf), disp: stateDispersion(uf)}); }
  rows.sort((a,b)=>b.avg.lula-a.avg.lula);
  document.getElementById('rankList').innerHTML = rows.map(r=>{
    const w = r.avg.has ? r.avg.lula : 50;
    const color = r.avg.has ? colorFor(r.avg.lula) : 'var(--border-strong,#cdbf9c)';
    const label = r.avg.has ? r.avg.lula.toFixed(1)+'%' : 'sem dados';
    const delta = r.delta===null ? '' : '<span class="ppbadge '+ppClass(r.delta)+'">'+ppArrow(r.delta)+' '+fmtPP(r.delta)+'</span>';
    const staleFlag = r.stale.stale ? '<span class="stalebadge" title="Pesquisa mais recente há '+r.stale.days+' dias">'+icon('clock')+' desatualizado</span>' : '';
    const tierFlag = r.disp.tier==='preliminar' ? '<span class="tierbadge preliminar" title="Apenas 1 pesquisa cadastrada">1 pesquisa</span>' : '';
    return '<div class="rowbar"><div class="uf">'+r.uf+'</div><div class="track"><div class="fill" style="width:'+w+'%;background:'+color+'"></div></div><div class="pct">'+label+'</div><div class="deltacell">'+delta+tierFlag+staleFlag+'</div></div>';
  }).join('');
  renderDecisive();
}

/* ---------- Estados decisivos (painel na aba Ranking) ------------------ */
function renderDecisive(){
  const el = document.getElementById('decisiveList');
  if(!el) return;
  const list = decisiveStates();
  if(!list.length){ el.innerHTML = '<p class="empty">Nenhum estado com pesquisa está abaixo da margem de '+DECISIVE_MARGIN+' p.p. no momento.</p>'; return; }
  el.innerHTML = list.map(d=>{
    return '<div class="decisivecard"><div class="dc-uf">'+NAMES[d.uf]+' <span class="muted">('+d.uf+')</span></div>'+
      '<div class="dc-bar"><div class="dc-fill" style="width:'+d.avg.lula+'%;background:'+colorFor(d.avg.lula)+'"></div></div>'+
      '<div class="dc-nums"><span>Lula '+d.avg.lula.toFixed(1)+'%</span><span class="muted">margem '+d.margin.toFixed(1)+' p.p.</span><span>Flávio '+d.avg.opp.toFixed(1)+'%</span></div></div>';
  }).join('');
}
/* ---------- Projeções matemáticas até o dia da eleição ----------------
   Dois modelos de regressão sobre a série consolidada nacional de Lula:
   1) Tendência linear simples (mínimos quadrados / OLS) — dá o mesmo peso
      a todas as pesquisas ao longo do tempo.
   2) Tendência ponderada por recência — mínimos quadrados ponderados,
      usando o mesmo decaimento por meia-vida das médias (pesquisas
      recentes pesam mais), o que captura melhor um "momentum" recente. */
function daysBetweenDates(aISO,bISO){
  return (new Date(bISO+'T00:00:00') - new Date(aISO+'T00:00:00')) / 86400000;
}
function olsRegression(xs,ys){
  const n=xs.length;
  const xbar=xs.reduce((a,b)=>a+b,0)/n, ybar=ys.reduce((a,b)=>a+b,0)/n;
  let num=0,den=0;
  for(let i=0;i<n;i++){ num += (xs[i]-xbar)*(ys[i]-ybar); den += (xs[i]-xbar)**2; }
  const slope = den ? num/den : 0;
  return {slope, intercept: ybar - slope*xbar};
}
function weightedRegression(xs,ys,ws){
  let sw=0,swx=0,swy=0,swxx=0,swxy=0;
  for(let i=0;i<xs.length;i++){
    const w=ws[i];
    sw+=w; swx+=w*xs[i]; swy+=w*ys[i]; swxx+=w*xs[i]*xs[i]; swxy+=w*xs[i]*ys[i];
  }
  const den = sw*swxx - swx*swx;
  const slope = den ? (sw*swxy - swx*swy)/den : 0;
  const intercept = sw ? (swy - slope*swx)/sw : (ys[ys.length-1]||50);
  return {slope, intercept};
}
function clampPct(v){ return Math.max(0, Math.min(100, v)); }

/* ---------- Correlação de Pearson: 2022 oficial × cenário atual (2026) -
   Técnica padrão de agregadores para checar o quanto o padrão estadual
   de uma eleição anterior "se repete" na atual: r perto de +1 significa
   que os estados que já eram fortes pra Lula em 2022 continuam sendo os
   mais fortes agora (mesma ordem relativa); perto de 0 significa que o
   padrão embaralhou; negativo significa que ele se inverteu. */
function pearsonCorrelation(xs, ys){
  const n = xs.length;
  if(n < 2) return null;
  const xbar = xs.reduce((a,b)=>a+b,0)/n, ybar = ys.reduce((a,b)=>a+b,0)/n;
  let sxy=0, sxx=0, syy=0;
  for(let i=0;i<n;i++){ const dx=xs[i]-xbar, dy=ys[i]-ybar; sxy+=dx*dy; sxx+=dx*dx; syy+=dy*dy; }
  if(sxx===0 || syy===0) return 0;
  return sxy / Math.sqrt(sxx*syy);
}
/* Pontos {uf, x:2022%, y:atual%, delta, n} para todo estado com pesquisa. */
function correlationPoints(){
  const out=[];
  for(const uf in DATA){
    const base = BASELINE_2022[uf];
    const avg = stateAvg(uf);
    if(!base || !avg.has) continue;
    out.push({uf, x:base.lula, y:avg.lula, delta:avg.lula-base.lula, n:(DATA[uf].polls||[]).length});
  }
  return out;
}

/* Ordena as pesquisas de UM estado por data (só as que têm data). */
function statePollsSorted(uf){
  return ((DATA[uf] && DATA[uf].polls) || []).filter(p=>p.date).sort((a,b)=>a.date<b.date?-1:a.date>b.date?1:0);
}

/* Projeção de UM estado até o dia da eleição, por modelo ('ols'|'wls').
   - 0 pesquisas no estado  -> assume o resultado oficial de 2022 (sem sinal, sem mudança).
   - 1 pesquisa no estado   -> não dá pra estimar tendência; mantém o valor mais recente.
   - 2+ pesquisas no estado -> regressão sobre a série própria do estado, extrapolada até 25/10. */
function stateProjection(uf, modelKey){
  const polls = statePollsSorted(uf);
  const base = BASELINE_2022[uf];
  if(polls.length===0) return base ? base.lula : 50;
  if(polls.length===1) return polls[0].lula;
  const t0 = polls[0].date;
  const xs = polls.map(p=>daysBetweenDates(t0,p.date));
  const ys = polls.map(p=>p.lula);
  const xTarget = Math.max(daysBetweenDates(t0, ELECTION_DAY), xs[xs.length-1]); // nunca projeta "para trás"
  const reg = modelKey==='ols'
    ? olsRegression(xs,ys)
    : weightedRegression(xs,ys, polls.map(p=>recencyWeight(p.date)));
  return clampPct(reg.intercept + reg.slope*xTarget);
}

/* Agrega as projeções de todos os 27 estados, ponderadas pelo peso
   eleitoral de 2022 de cada um — em vez de extrapolar a curva nacional
   "costurada" (que pulava conforme qual estado tinha pesquisa em cada
   data, e por isso podia dar números sem sentido). Cada estado contribui
   com o seu PRÓPRIO horizonte de projeção, o que é estatisticamente
   muito mais estável. */
function nationalProjection(modelKey){
  let sumW=0, sumL=0, coveredWeight=0, trendWeight=0;
  for(const uf in DATA){
    const w = DATA[uf].weight;
    sumW += w; sumL += stateProjection(uf, modelKey) * w;
    const n = statePollsSorted(uf).length;
    if(n>=1) coveredWeight += w;
    if(n>=2) trendWeight += w;
  }
  return {lula: sumW? sumL/sumW : 50, coveredWeight, trendWeight};
}

function computeProjections(){
  const totalPolls = Object.values(DATA).reduce((a,s)=>a+((s.polls||[]).length),0);
  if(totalPolls===0) return null;
  return { ols: nationalProjection('ols'), wls: nationalProjection('wls') };
}

/* ---------- Peso eleitoral coberto vs. total (métrica isolada) --------- */
function coverageWeight(){
  let covered=0, total=0;
  for(const uf in DATA){ const w=DATA[uf].weight; total+=w; if(((DATA[uf].polls||[]).length)>0) covered+=w; }
  return {covered, total, pct: total? covered/total*100 : 0};
}

/* ---------- Estados decisivos: margem Lula×Flávio abaixo do limiar ----- */
function decisiveStates(){
  const out=[];
  for(const uf in DATA){
    const avg = stateAvg(uf);
    if(!avg.has) continue;
    const margin = Math.abs(avg.lula-avg.opp);
    if(margin < DECISIVE_MARGIN) out.push({uf, avg, margin});
  }
  return out.sort((a,b)=>a.margin-b.margin);
}

/* ---------- Ranking / média / efeito de casa por instituto (group-by) -- */
function instituteStats(){
  const byInst = {};
  for(const uf in DATA){
    (DATA[uf].polls||[]).forEach(p=>{
      const s = byInst[p.inst] || (byInst[p.inst] = {inst:p.inst, count:0, states:new Set(), sumLula:0, sumCred:0});
      s.count++; s.states.add(uf); s.sumLula += p.lula; s.sumCred += p.cred;
    });
  }
  return Object.values(byInst).map(s=>({
    inst: s.inst, count: s.count, states: s.states.size,
    rawAvg: s.sumLula/s.count, avgCred: s.sumCred/s.count,
    houseEffect: HOUSE_EFFECTS[s.inst] !== undefined ? HOUSE_EFFECTS[s.inst] : null
  })).sort((a,b)=> b.count-a.count);
}

/* ---------- Última alternância de liderança nacional -------------------
   Percorre a série consolidada nacional (mesma lógica do gráfico de linha
   do tempo) e encontra a data mais recente em que o líder mudou (Lula
   passou a liderar, ou deixou de liderar, os 50%). */
function lastLeadershipChange(points){
  if(!points || points.length<2) return null;
  let lastChange=null, prevLeader = points[0].lula>=50 ? 'lula':'opp';
  for(let i=1;i<points.length;i++){
    const leader = points[i].lula>=50 ? 'lula':'opp';
    if(leader!==prevLeader){ lastChange = {date:points[i].date, newLeader:leader}; prevLeader=leader; }
  }
  return lastChange;
}

function renderTimeline(){
  const svg=document.getElementById('timeSvg');
  const all=[];
  for(const uf in DATA){
    for(const p of (DATA[uf].polls||[])){ if(p.date) all.push({uf,date:p.date,lula:p.lula}); }
  }
  all.sort((a,b)=> a.date < b.date ? -1 : a.date > b.date ? 1 : 0);
  const proj = computeProjections();
  if(all.length===0){
    svg.innerHTML = '<foreignObject x="0" y="0" width="800" height="320"><div xmlns="http://www.w3.org/1999/xhtml" class="chart-empty">Adicione pesquisas com data para ver a evolução no tempo.</div></foreignObject>';
    renderProjectionPanel(proj);
    renderLeadershipInfo(null);
    return;
  }

  // Recalcula a média nacional a cada evento, mas SÓ guarda um ponto por
  // data única (o estado consolidado ao fim daquele dia) — antes cada
  // pesquisa virava um ponto separado, mesmo quando duas pesquisas caíam
  // no mesmo dia, o que gerava pontos "empilhados" na mesma posição do
  // eixo X (o efeito de duplicação que ficava ilegível no gráfico).
  const latest={};
  const byDate = new Map(); // date -> {lula, opp}
  for(const item of all){
    latest[item.uf]=item;
    let sumL=0,sumW=0;
    for(const uf in latest){ sumL += latest[uf].lula * DATA[uf].weight; sumW += DATA[uf].weight; }
    const lula = sumW? sumL/sumW : 50;
    byDate.set(item.date, {date:item.date, lula, opp:100-lula});
  }
  const points = Array.from(byDate.values()); // já em ordem cronológica (Map preserva inserção, e "all" está ordenado)

  const W=800,H=340,padL=42,padR=20,padT=30,padB=38;
  const t0 = new Date(points[0].date+'T00:00:00').getTime();
  const lastDate = points[points.length-1].date;
  // o domínio do eixo X vai até a maior das duas datas: a última pesquisa
  // OU o dia da eleição (para caber a linha pontilhada de projeção)
  const showProj = !!proj;
  const t1raw = new Date(lastDate+'T00:00:00').getTime();
  const tElection = new Date(ELECTION_DAY+'T00:00:00').getTime();
  const t1 = showProj ? Math.max(t1raw, tElection) : t1raw;
  const span = Math.max(1, t1 - t0);
  const xOf=(dateISO)=> points.length===1 && !showProj
    ? (W-padL-padR)/2 + padL
    : padL + ((new Date(dateISO+'T00:00:00').getTime()-t0)/span)*(W-padL-padR);
  const xs=(p)=> xOf(p.date);
  const ys=(v)=> padT + (100-v)/100*(H-padT-padB);

  // pontos de tela (px) pra cada série, usados tanto pra desenhar quanto
  // pra alimentar a curva suavizada (smoothLinePath só recebe {x,y})
  const lulaPts = points.map(p=>({x:xs(p), y:ys(p.lula)}));
  const oppPts  = points.map(p=>({x:xs(p), y:ys(p.opp)}));

  let svgc='';
  // grade horizontal: linhas fortes em 0/25/50/75/100 + linhas finas
  // intermediárias a cada 10%, estilo painel de agregador profissional
  for(let v=0; v<=100; v+=10){
    const y = ys(v);
    const major = (v%25===0);
    svgc += '<line x1="'+padL+'" y1="'+y.toFixed(1)+'" x2="'+(W-padR)+'" y2="'+y.toFixed(1)+'" class="gridline'+(major?'':' minor')+'"'+(v===50?' stroke-dasharray="3,4"':'')+'/>';
    if(major) svgc += '<text x="'+(padL-8)+'" y="'+(y+3.5).toFixed(1)+'" class="axislabel" text-anchor="end">'+v+'%</text>';
  }

  // grade vertical: até 6 marcas de data uniformemente espaçadas ao longo
  // do período coberto, formatadas curtas (dd/mm) — bem mais legível que
  // só 3 rótulos quando a série cobre muitos meses.
  const tickDates = [];
  {
    const nTicks = Math.min(6, Math.max(2, points.length));
    for(let i=0;i<nTicks;i++){
      const t = t0 + (span*i)/(nTicks-1);
      tickDates.push(new Date(t));
    }
  }
  tickDates.forEach((d,i)=>{
    const x = padL + ((d.getTime()-t0)/span)*(W-padL-padR);
    if(x < padL-1 || x > W-padR+1) return;
    svgc += '<line x1="'+x.toFixed(1)+'" y1="'+padT+'" x2="'+x.toFixed(1)+'" y2="'+(H-padB)+'" class="gridline vgrid"/>';
    const dd = String(d.getDate()).padStart(2,'0'), mm = String(d.getMonth()+1).padStart(2,'0');
    const anchor = i===0 ? 'start' : (i===tickDates.length-1 && !showProj ? 'end' : 'middle');
    svgc += '<text x="'+x.toFixed(1)+'" y="'+(H-12)+'" class="axislabel" text-anchor="'+anchor+'">'+dd+'/'+mm+'</text>';
  });

  // marcador vertical do dia da eleição
  if(showProj){
    const xe = xOf(ELECTION_DAY);
    svgc += '<line x1="'+xe.toFixed(1)+'" y1="'+padT+'" x2="'+xe.toFixed(1)+'" y2="'+(H-padB)+'" class="electionline"/>';
    svgc += '<text x="'+xe.toFixed(1)+'" y="'+(padT-10)+'" class="axislabel electionlabel" text-anchor="middle">25/10 · eleição</text>';
  }

  // legenda no topo, no estilo dos "chips" coloridos do Google Trends
  svgc += '<g class="chartlegend">'+
    '<circle cx="'+padL+'" cy="12" r="4.5" fill="var(--lula,#a3392c)"/><text x="'+(padL+11)+'" y="15.5" class="legendlabel">Lula</text>'+
    '<circle cx="'+(padL+58)+'" cy="12" r="4.5" fill="var(--opp,#31506a)"/><text x="'+(padL+69)+'" y="15.5" class="legendlabel">Flávio</text>'+
  '</g>';

  // área sob a linha do Lula, preenchida com a textura pontilhada
  // ("halftone") — a assinatura gráfica do site — agora seguindo a
  // mesma curva suave da linha, em vez de segmentos retos.
  svgc += '<path d="'+smoothAreaPath(lulaPts, H-padB)+'" class="timeline-area"/>';

  // linha Flávio (traço mais fino, por trás) + linha Lula (em destaque, por cima), ambas suavizadas
  svgc += '<path d="'+smoothLinePath(oppPts)+'" class="timeline-line opp"/>';
  svgc += '<path d="'+smoothLinePath(lulaPts)+'" class="timeline-line lula"/>';

  points.forEach((p,i)=>{
    const x=xs(p).toFixed(1);
    svgc += '<circle cx="'+x+'" cy="'+ys(p.opp).toFixed(1)+'" r="3" class="timeline-dot opp" data-i="'+i+'"><title>'+fmtDate(p.date)+': Flávio '+p.opp.toFixed(1)+'%</title></circle>';
    svgc += '<circle cx="'+x+'" cy="'+ys(p.lula).toFixed(1)+'" r="3.6" class="timeline-dot lula" data-i="'+i+'"><title>'+fmtDate(p.date)+': Lula '+p.lula.toFixed(1)+'%</title></circle>';
  });

  // linhas pontilhadas de projeção — dos dois modelos — até o dia da eleição
  if(showProj){
    const last = points[points.length-1];
    const xe = xOf(ELECTION_DAY).toFixed(1);
    const x0 = xs(last).toFixed(1);
    svgc += '<path d="M'+x0+','+ys(last.lula).toFixed(1)+' L'+xe+','+ys(proj.ols.lula).toFixed(1)+'" class="proj-line ols"/>';
    svgc += '<path d="M'+x0+','+ys(last.lula).toFixed(1)+' L'+xe+','+ys(proj.wls.lula).toFixed(1)+'" class="proj-line wls"/>';
    svgc += '<circle cx="'+xe+'" cy="'+ys(proj.ols.lula).toFixed(1)+'" r="4" class="proj-dot ols"><title>Tendência linear simples em 25/10: Lula '+proj.ols.lula.toFixed(1)+'%</title></circle>';
    svgc += '<circle cx="'+xe+'" cy="'+ys(proj.wls.lula).toFixed(1)+'" r="4" class="proj-dot wls"><title>Tendência ponderada por recência em 25/10: Lula '+proj.wls.lula.toFixed(1)+'%</title></circle>';
  }

  // rótulos de valor direto no fim de cada linha (como Economist/FT fazem
  // em vez de depender só da legenda) — mostram o último valor conhecido.
  const lastP = points[points.length-1];
  const lx = xs(lastP);
  [['lula', lastP.lula, 8], ['opp', lastP.opp, -8]].forEach(([key,val,dy])=>{
    const ly = ys(val);
    const txt = val.toFixed(1)+'%';
    const bw = 15 + txt.length*6.4;
    svgc += '<rect x="'+(lx+7).toFixed(1)+'" y="'+(ly+dy-9).toFixed(1)+'" width="'+bw.toFixed(1)+'" height="16" rx="8" class="endlabel-bg"/>';
    svgc += '<text x="'+(lx+7+bw/2).toFixed(1)+'" y="'+(ly+dy+2.5).toFixed(1)+'" class="endlabel '+key+'" text-anchor="middle">'+txt+'</text>';
  });

  svgc += '<line x1="'+padL+'" y1="'+(H-padB)+'" x2="'+(W-padR)+'" y2="'+(H-padB)+'" class="gridline strong"/>';

  // zona invisível que captura o mouse em toda a área do gráfico, usada
  // pelo listener de hover instalado logo abaixo (crosshair + tooltip).
  svgc += '<rect x="'+padL+'" y="'+padT+'" width="'+(W-padL-padR)+'" height="'+(H-padT-padB)+'" class="hoverzone" data-hover="1"/>';
  svgc += '<g id="timeHoverLayer" style="display:none;">'+
    '<line x1="0" y1="'+padT+'" x2="0" y2="'+(H-padB)+'" class="crosshair" id="timeCrosshair"/>'+
    '<circle r="5" class="hoverdot lula" id="timeHoverLula"/>'+
    '<circle r="4.5" class="hoverdot opp" id="timeHoverOpp"/>'+
  '</g>';

  svg.innerHTML = svgc;
  renderProjectionPanel(proj);
  renderLeadershipInfo(lastLeadershipChange(points));
  attachTimelineHover(svg, points, xs, ys, W, H);
}
/* ---------- Interatividade: crosshair + tooltip ao passar o mouse ------
   Reatribuído a cada renderTimeline() porque o SVG é reconstruído do
   zero (innerHTML) a cada atualização. Encontra o ponto de dado mais
   próximo do X do mouse e realça os dois valores daquela data. */
function attachTimelineHover(svg, points, xsFn, ysFn, W, H){
  const zone = svg.querySelector('[data-hover]');
  const layer = document.getElementById('timeHoverLayer');
  const crosshair = document.getElementById('timeCrosshair');
  const dotLula = document.getElementById('timeHoverLula');
  const dotOpp = document.getElementById('timeHoverOpp');
  const tooltip = document.getElementById('timeTooltip');
  const wrap = document.getElementById('timeSvgWrap');
  if(!zone || !layer || !tooltip || !wrap || !points.length) return;
  const xPositions = points.map(p=>xsFn(p));
  function nearestIndex(mx){
    let best=0, bestD=Infinity;
    xPositions.forEach((x,i)=>{ const d=Math.abs(x-mx); if(d<bestD){ bestD=d; best=i; } });
    return best;
  }
  function move(evt){
    const rect = svg.getBoundingClientRect();
    const clientX = evt.touches ? evt.touches[0].clientX : evt.clientX;
    const mxSvg = ((clientX - rect.left) / rect.width) * W;
    const i = nearestIndex(mxSvg);
    const p = points[i];
    const x = xsFn(p), yL = ysFn(p.lula), yO = ysFn(p.opp);
    layer.style.display = '';
    crosshair.setAttribute('x1', x); crosshair.setAttribute('x2', x);
    dotLula.setAttribute('cx', x); dotLula.setAttribute('cy', yL);
    dotOpp.setAttribute('cx', x); dotOpp.setAttribute('cy', yO);
    tooltip.hidden = false;
    tooltip.innerHTML = '<span class="tt-date">'+fmtDate(p.date)+'</span>'+
      '<span class="tt-lula">● Lula '+p.lula.toFixed(1)+'%</span><br>'+
      '<span class="tt-opp">● Flávio '+p.opp.toFixed(1)+'%</span>';
    const left = clientX - rect.left;
    const top = yL * (rect.height / H);
    tooltip.style.left = Math.min(Math.max(left,50), rect.width-50)+'px';
    tooltip.style.top = Math.max(top, 24)+'px';
  }
  function leave(){ layer.style.display='none'; tooltip.hidden = true; }
  zone.addEventListener('mousemove', move);
  zone.addEventListener('mouseleave', leave);
  zone.addEventListener('touchmove', move, {passive:true});
  zone.addEventListener('touchend', leave);
}
function renderLeadershipInfo(change){
  const el = document.getElementById('leadershipInfo');
  if(!el) return;
  if(!change){ el.innerHTML=''; return; }
  const who = change.newLeader==='lula' ? 'Lula assumiu a liderança' : 'Lula perdeu a liderança (Flávio passou à frente)';
  el.innerHTML = '<span class="leadchip">'+icon('repeat')+' Última alternância de liderança nacional: <b>'+fmtDate(change.date)+'</b> — '+who+'</span>';
}

function renderProjectionPanel(proj){
  const el = document.getElementById('timelineProjections');
  if(!el) return;
  if(!proj){
    el.innerHTML = '<p class="empty">Cadastre ao menos uma pesquisa para ver a projeção até a eleição.</p>';
    return;
  }
  const days = Math.max(0, Math.round(daysBetweenDates(todayISO(), ELECTION_DAY)));
  const card = (title, desc, lula, trendWeight, cls)=>{
    const opp = 100-lula;
    return '<div class="projcard '+cls+'">'+
      '<div class="projcard-head"><span class="projdot"></span><h4>'+title+'</h4></div>'+
      '<p class="projdesc">'+desc+'</p>'+
      '<div class="projresult"><b>Lula '+lula.toFixed(1)+'%</b><span class="muted">× Flávio '+opp.toFixed(1)+'%</span></div>'+
      '<div class="projmeta">'+(trendWeight*100).toFixed(0)+'% do peso eleitoral tem tendência própria calculada (2+ pesquisas no estado)</div>'+
    '</div>';
  };
  el.innerHTML =
    '<p class="section-sub">Projeção para <b>25/10/2026</b> ('+days+' dia(s) restantes). Cada estado é projetado com base na <b>sua própria</b> série de pesquisas (2+ pesquisas → tendência; 1 pesquisa → mantém o valor; 0 pesquisas → assume o resultado de 2022), e o resultado nacional é a soma ponderada pelo peso eleitoral de cada estado — <b>'+(proj.ols.coveredWeight*100).toFixed(0)+'% do peso nacional</b> já tem pesquisa cadastrada. São estimativas estatísticas simples, não previsões oficiais.</p>'+
    '<div class="projgrid">'+
      card('Tendência linear simples', 'Regressão linear (mínimos quadrados) sobre a série de cada estado, mesmo peso para toda pesquisa.', proj.ols.lula, proj.ols.trendWeight, 'ols')+
      card('Tendência ponderada por recência', 'Regressão linear ponderada por estado: pesquisas mais recentes pesam mais (meia-vida de '+RECENCY_HALF_LIFE_DAYS+' dias), capturando melhor o momentum atual.', proj.wls.lula, proj.wls.trendWeight, 'wls')+
    '</div>';
}
function renderStats(){
  let covered=0,total=0,lastDate=null;
  for(const uf in DATA){
    const polls=DATA[uf].polls||[];
    if(polls.length){ covered++; total+=polls.length; }
    for(const p of polls){ if(p.date && (!lastDate || p.date>lastDate)) lastDate=p.date; }
  }
  document.getElementById('statCoverage').textContent = covered+' / '+Object.keys(DATA).length;
  document.getElementById('statPolls').textContent = total;
  document.getElementById('statLast').textContent = lastDate ? fmtDate(lastDate) : '—';

  const days = Math.max(0, Math.round(daysBetweenDates(todayISO(), ELECTION_DAY)));
  const statCountdown = document.getElementById('statCountdown');
  if(statCountdown) statCountdown.textContent = days+' dia'+(days===1?'':'s');

  const cw = coverageWeight();
  const statCoverW = document.getElementById('statCoverW');
  if(statCoverW) statCoverW.textContent = cw.pct.toFixed(1)+'%';
}

/* ---------- Aba Institutos: ranking de atividade + média por instituto
   + efeito de casa (house effect). Tudo group-by sobre os dados já
   existentes — nenhum campo novo precisou ser cadastrado. ---------- */
function renderInstitutes(){
  const wrap = document.getElementById('instituteList');
  if(!wrap) return;
  const stats = instituteStats();
  if(!stats.length){ wrap.innerHTML = '<p class="empty">Cadastre pesquisas para ver o ranking de institutos.</p>'; return; }
  const maxCount = Math.max(...stats.map(s=>s.count));
  const rows = stats.map(s=>{
    const heHtml = s.houseEffect===null
      ? '<span class="muted">— (só nele mesmo)</span>'
      : '<span class="ppbadge '+(s.houseEffect>0.3?'up':s.houseEffect<-0.3?'down':'flat')+'" title="Diferença média frente ao consenso de outros institutos no mesmo estado">'+(s.houseEffect>0?'+':'')+s.houseEffect.toFixed(1)+' p.p.</span>';
    return '<tr><td>'+s.inst+'</td><td class="num">'+s.count+'</td><td class="num">'+s.states+'</td><td class="num">'+s.rawAvg.toFixed(1)+'%</td><td class="num">'+s.avgCred.toFixed(1)+'</td><td class="num">'+heHtml+'</td></tr>';
  }).join('');
  const bars = stats.map(s=>
    '<div class="rowbar"><div class="uf instname" title="'+s.inst+'">'+s.inst+'</div><div class="track"><div class="fill" style="width:'+(s.count/maxCount*100)+'%;background:var(--brand)"></div></div><div class="pct">'+s.count+'</div></div>'
  ).join('');
  wrap.innerHTML =
    '<h3 class="subhead">Atividade por instituto</h3>'+
    '<div class="section-sub">Quantas pesquisas cada instituto tem cadastradas no total — mais pesquisas de um mesmo instituto não significam mais precisão, mas ajudam a estimar o efeito de casa dele com mais confiança.</div>'+
    bars+
    '<h3 class="subhead" style="margin-top:22px;">Média bruta e efeito de casa</h3>'+
    '<div class="section-sub">O <b>efeito de casa</b> é o viés médio de um instituto frente ao consenso de outros institutos no mesmo estado (mesma técnica usada por agregadores como FiveThirtyEight e Split Ticket). Valor positivo = tende a favorecer Lula frente ao consenso; negativo = tende a favorecer Flávio.</div>'+
    '<div class="table-scroll"><table><thead><tr><th>Instituto</th><th>Pesquisas</th><th>Estados</th><th>Média bruta (Lula)</th><th>Cred. média</th><th>Efeito de casa</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
}

/* ---------- Insights regionais ---------- */
function renderRegions(){
  const wrap = document.getElementById('regionList');
  const cards = REGION_ORDER.map(region=>{
    const ufs = REGIONS[region];
    let curW=0, curL=0, baseW=0, baseL=0, covered=0, totalPolls=0;
    ufs.forEach(uf=>{
      const base = BASELINE_2022[uf];
      const w = base.weight;
      baseW += w; baseL += base.lula*w;
      const avg = stateAvg(uf);
      const polls = (DATA[uf] && DATA[uf].polls) || [];
      totalPolls += polls.length;
      if(avg.has){ covered++; curW += w; curL += avg.lula*w; }
    });
    const baseAvg = baseL/baseW;
    const hasCur = curW>0;
    const curAvg = hasCur ? curL/curW : null;
    const delta = hasCur ? curAvg - baseAvg : null;
    const nationalShare = baseW; // peso da região no total nacional (2022)
    return {region, ufs, baseAvg, curAvg, delta, covered, total:ufs.length, totalPolls, nationalShare};
  });

  wrap.innerHTML = cards.map(c=>{
    const barCur = c.curAvg===null ? null : c.curAvg;
    const deltaHtml = c.delta===null
      ? '<span class="ppbadge flat">sem pesquisas na região</span>'
      : '<span class="ppbadge '+ppClass(c.delta)+'">'+ppArrow(c.delta)+' '+fmtPP(c.delta)+' vs 2022</span>';
    return '<div class="regioncard">'+
      '<div class="regioncard-head">'+
        '<h3>'+c.region+'</h3>'+
        '<span class="regionshare">'+(c.nationalShare*100).toFixed(1)+'% do eleitorado nacional (2022)</span>'+
      '</div>'+
      '<div class="regioncard-body">'+
        '<div class="regionmetric">'+
          '<div class="rk">2022 (Lula × Bolsonaro)</div>'+
          '<div class="rv">'+c.baseAvg.toFixed(1)+'% <span class="muted">× '+(100-c.baseAvg).toFixed(1)+'%</span></div>'+
        '</div>'+
        '<div class="regionmetric">'+
          '<div class="rk">Média atual (Lula × Flávio)</div>'+
          '<div class="rv">'+(barCur===null? '— sem dados' : barCur.toFixed(1)+'% <span class="muted">× '+(100-barCur).toFixed(1)+'%</span>')+'</div>'+
        '</div>'+
        '<div class="regionmetric">'+
          '<div class="rk">Variação de Lula</div>'+
          '<div class="rv">'+deltaHtml+'</div>'+
        '</div>'+
      '</div>'+
      '<div class="regioncard-foot">'+c.covered+' de '+c.total+' estados com pesquisa · '+c.totalPolls+' pesquisa(s) cadastrada(s)</div>'+
    '</div>';
  }).join('');

  const withDelta = Object.keys(BASELINE_2022).filter(uf=>stateDelta(uf)!==null)
    .map(uf=>({uf, delta:stateDelta(uf)}));
  const insightsEl = document.getElementById('regionInsights');
  if(withDelta.length===0){
    insightsEl.innerHTML = '<p class="empty">Cadastre pesquisas em ao menos um estado para ver os destaques de oscilação em relação a 2022.</p>';
  } else {
    const sorted = [...withDelta].sort((a,b)=>b.delta-a.delta);
    const best = sorted.slice(0,3);
    const worst = sorted.slice(-3).reverse();
    const li = (arr)=> arr.map(x=>'<li><b>'+NAMES[x.uf]+'</b> <span class="ppbadge '+ppClass(x.delta)+'">'+ppArrow(x.delta)+' '+fmtPP(x.delta)+'</span></li>').join('');
    insightsEl.innerHTML =
      '<div class="insightcol"><h4>Maior avanço de Lula vs 2022</h4><ul>'+li(best)+'</ul></div>'+
      '<div class="insightcol"><h4>Maior recuo de Lula vs 2022</h4><ul>'+li(worst)+'</ul></div>';
  }
}

/* ---------- Gráfico de correlação (Pearson): 2022 oficial × cenário atual
   Dispersão (scatter) estado a estado, eixo X = 2022, eixo Y = média
   atual, com a diagonal "sem mudança" e a reta de regressão (mínimos
   quadrados) para leitura visual imediata do quanto o padrão de 2022
   ainda explica o cenário de 2026 — a mesma leitura de "swing" que
   agregadores como o pdvoto mostram entre duas eleições. */
function renderCorrelation(){
  const svg = document.getElementById('corrSvg');
  const statsEl = document.getElementById('corrStats');
  if(!svg) return;
  const pts = correlationPoints();
  if(pts.length < 2){
    svg.innerHTML = '<foreignObject x="0" y="0" width="640" height="360"><div xmlns="http://www.w3.org/1999/xhtml" class="chart-empty">Cadastre pesquisas em pelo menos 2 estados para calcular a correlação com 2022.</div></foreignObject>';
    if(statsEl) statsEl.innerHTML = '';
    return;
  }
  const xsData = pts.map(p=>p.x), ysData = pts.map(p=>p.y);
  const r = pearsonCorrelation(xsData, ysData);
  const r2 = r*r;
  const fit = olsRegression(xsData, ysData);

  const allVals = xsData.concat(ysData);
  let dmin = Math.floor((Math.min(...allVals)-5)/10)*10;
  let dmax = Math.ceil((Math.max(...allVals)+5)/10)*10;
  dmin = Math.max(0, dmin); dmax = Math.min(100, dmax);
  if(dmax-dmin < 20){ dmin=Math.max(0,dmin-10); dmax=Math.min(100,dmax+10); }

  const W=640,H=640,padL=48,padR=22,padT=22,padB=48;
  const plotW = W-padL-padR, plotH = H-padT-padB;
  const xOf = v => padL + ((v-dmin)/(dmax-dmin))*plotW;
  const yOf = v => padT + (1-(v-dmin)/(dmax-dmin))*plotH;

  let svgc='';
  // grade quadrada — mesmas marcas nos dois eixos, pra deixar claro que é a mesma escala (0–100%)
  for(let v=Math.ceil(dmin/10)*10; v<=dmax; v+=10){
    const x=xOf(v), y=yOf(v);
    const major = v%20===0;
    svgc += '<line x1="'+x.toFixed(1)+'" y1="'+padT+'" x2="'+x.toFixed(1)+'" y2="'+(H-padB)+'" class="gridline'+(major?'':' minor')+'"/>';
    svgc += '<line x1="'+padL+'" y1="'+y.toFixed(1)+'" x2="'+(W-padR)+'" y2="'+y.toFixed(1)+'" class="gridline'+(major?'':' minor')+'"/>';
    if(major){
      svgc += '<text x="'+x.toFixed(1)+'" y="'+(H-padB+16)+'" class="axislabel" text-anchor="middle">'+v+'%</text>';
      svgc += '<text x="'+(padL-8)+'" y="'+(y+3.5).toFixed(1)+'" class="axislabel" text-anchor="end">'+v+'%</text>';
    }
  }
  svgc += '<line x1="'+padL+'" y1="'+(H-padB)+'" x2="'+(W-padR)+'" y2="'+(H-padB)+'" class="gridline strong"/>';
  svgc += '<line x1="'+padL+'" y1="'+padT+'" x2="'+padL+'" y2="'+(H-padB)+'" class="gridline strong"/>';
  svgc += '<text x="'+((padL+W-padR)/2).toFixed(1)+'" y="'+(H-14)+'" class="axistitle" text-anchor="middle">% de Lula — resultado oficial 2022</text>';
  svgc += '<text x="16" y="'+((padT+H-padB)/2).toFixed(1)+'" class="axistitle" text-anchor="middle" transform="rotate(-90 16 '+((padT+H-padB)/2).toFixed(1)+')">% de Lula — média atual (2026)</text>';

  // diagonal "sem mudança" (y = x)
  svgc += '<path d="M'+xOf(dmin).toFixed(1)+','+yOf(dmin).toFixed(1)+' L'+xOf(dmax).toFixed(1)+','+yOf(dmax).toFixed(1)+'" class="diagline"/>';
  svgc += '<text x="'+(xOf(dmax)-6).toFixed(1)+'" y="'+(yOf(dmax)-8).toFixed(1)+'" class="diaglabel" text-anchor="end">sem mudança vs 2022</text>';

  // reta de regressão (mínimos quadrados) entre os pontos
  const fitY1 = fit.intercept + fit.slope*dmin, fitY2 = fit.intercept + fit.slope*dmax;
  svgc += '<path d="M'+xOf(dmin).toFixed(1)+','+yOf(fitY1).toFixed(1)+' L'+xOf(dmax).toFixed(1)+','+yOf(fitY2).toFixed(1)+'" class="fitline"/>';

  // legenda
  svgc += '<g class="chartlegend">'+
    '<circle cx="'+(padL+6)+'" cy="'+(padT+10)+'" r="4.5" fill="var(--up)"/><text x="'+(padL+16)+'" y="'+(padT+13.5)+'" class="corrlegend">Avançou vs 2022</text>'+
    '<circle cx="'+(padL+140)+'" cy="'+(padT+10)+'" r="4.5" fill="var(--down)"/><text x="'+(padL+150)+'" y="'+(padT+13.5)+'" class="corrlegend">Recuou vs 2022</text>'+
  '</g>';

  pts.forEach(p=>{
    const x=xOf(p.x), y=yOf(p.y);
    const cls = p.delta>0.5?'up':p.delta<-0.5?'down':'flat';
    svgc += '<circle cx="'+x.toFixed(1)+'" cy="'+y.toFixed(1)+'" r="6.5" class="corr-dot '+cls+'" data-uf="'+p.uf+'"><title>'+NAMES[p.uf]+' ('+p.uf+')\n2022: '+p.x.toFixed(1)+'% · agora: '+p.y.toFixed(1)+'% · variação: '+fmtPP(p.delta)+' · '+p.n+' pesquisa(s)</title></circle>';
    svgc += '<text x="'+(x+9).toFixed(1)+'" y="'+(y+3.2).toFixed(1)+'" class="corr-label">'+p.uf+'</text>';
  });

  svg.innerHTML = svgc;
  attachCorrHover(svg, pts, xOf, yOf);

  if(statsEl){
    const tier = r>=0.7 ? 'padrão de 2022 fortemente preservado'
      : r>=0.4 ? 'padrão de 2022 parcialmente preservado'
      : r>=0 ? 'padrão de 2022 fracamente relacionado'
      : 'padrão de 2022 invertido';
    statsEl.innerHTML =
      '<div class="corrstat"><div class="k">Correlação de Pearson (r)</div><div class="v">'+r.toFixed(3)+'</div></div>'+
      '<div class="corrstat"><div class="k">R² (variância explicada)</div><div class="v">'+(r2*100).toFixed(1)+'<span class="unit">%</span></div></div>'+
      '<div class="corrstat"><div class="k">Estados na amostra</div><div class="v">'+pts.length+'<span class="unit">/ 27</span></div></div>'+
      '<div class="corrstat"><div class="k">Leitura</div><div class="v" style="font-size:.92rem;line-height:1.3;">'+tier+'</div></div>';
  }
}
function attachCorrHover(svg, pts, xOf, yOf){
  const tooltip = document.getElementById('corrTooltip');
  const wrap = document.getElementById('corrSvgWrap');
  if(!tooltip || !wrap) return;
  svg.querySelectorAll('.corr-dot').forEach(dot=>{
    const uf = dot.getAttribute('data-uf');
    const p = pts.find(x=>x.uf===uf);
    if(!p) return;
    dot.addEventListener('mouseenter', ()=>{
      dot.classList.add('hi');
      const rect = svg.getBoundingClientRect();
      const x = xOf(p.x)*(rect.width/640), y = yOf(p.y)*(rect.width/640);
      tooltip.hidden=false;
      tooltip.innerHTML = '<span class="tt-date">'+NAMES[uf]+' ('+uf+')</span>'+
        '2022: <b>'+p.x.toFixed(1)+'%</b> · agora: <b>'+p.y.toFixed(1)+'%</b><br>'+
        'variação: <b>'+fmtPP(p.delta)+'</b> · '+p.n+' pesquisa'+(p.n===1?'':'s');
      tooltip.style.left = Math.min(Math.max(x,60), rect.width-60)+'px';
      tooltip.style.top = Math.max(y,24)+'px';
    });
    dot.addEventListener('mouseleave', ()=>{ dot.classList.remove('hi'); tooltip.hidden=true; });
  });
}

function renderAll(){
  HOUSE_EFFECTS = houseEffects();
  renderMap(); renderBar(); renderRank(); renderTimeline(); renderStats(); renderRegions(); renderInstitutes(); renderCorrelation();
  if(selectedUF) renderPanel(selectedUF);
}

function openPanel(uf){
  selectedUF=uf;
  editingIndex=null;
  renderPanel(uf);
}
const METHOD_LABEL = {ponderada:'ponderada por credibilidade e recência', simples:'simples', ajustada:'ponderada + efeito de casa corrigido'};
function renderPanel(uf){
  const avg=stateAvg(uf);
  const base=BASELINE_2022[uf];
  const delta=stateDelta(uf);
  const disp=stateDispersion(uf);
  const trend=stateTrendSimple(uf);
  const stale=stateStale(uf);
  const polls=(DATA[uf].polls||[]).map((p,i)=>({...p,_i:i})).sort((a,b)=> (b.date||'').localeCompare(a.date||''));
  const editing = editingIndex!==null ? (DATA[uf].polls||[])[editingIndex] : null;
  let rows = polls.map(p=>{
    const rw = p.date ? recencyWeight(p.date) : 1;
    return '<tr'+(p._i===editingIndex?' class="editing"':'')+'><td>'+p.inst+'</td><td class="num">'+fmtDate(p.date)+'</td><td class="num">'+p.lula.toFixed(1)+'%</td><td class="num">'+p.opp.toFixed(1)+'%</td><td class="num">'+p.cred+'</td><td class="num" title="Peso por recência (meia-vida de '+RECENCY_HALF_LIFE_DAYS+' dias)">'+Math.round(rw*100)+'%</td>'+
      '<td class="rowactions"><button class="ic ed" data-i="'+p._i+'" title="Editar">'+icon('edit')+'</button><button class="ic rm" data-i="'+p._i+'" title="Remover">'+icon('remove')+'</button></td></tr>';
  }).join('');
  const avgLine = avg.has
    ? 'Média atual ('+METHOD_LABEL[method]+'): <b>Lula '+avg.lula.toFixed(1)+'%</b>'+(disp.moe!==null?' <span class="moe">± '+disp.moe.toFixed(1)+' p.p.</span>':'')+' × <b>Flávio '+avg.opp.toFixed(1)+'%</b>'
    : 'Nenhuma pesquisa cadastrada ainda para este estado.';
  const badgeRow = avg.has ? (
    '<div class="statsrow">'+
      '<span class="tierbadge '+disp.tier+'" title="Baseada no número de pesquisas e na concordância entre elas">'+
        signalIcon(disp.tier)+' '+TIER_LABEL[disp.tier]+' · '+disp.n+' pesquisa'+(disp.n===1?'':'s')+
      '</span>'+
      (disp.divergence!==null && disp.n>1 ? '<span class="divbadge" title="Diferença entre a pesquisa mais alta e a mais baixa (Lula) no estado">'+icon('divergence')+' divergência '+disp.divergence.toFixed(1)+' p.p.</span>' : '')+
      (trend ? '<span class="ppbadge '+trend.dir+'">'+trendIcon(trend.dir)+' tendência '+(trend.delta>0?'+':'')+trend.delta.toFixed(1)+' p.p. desde '+fmtDate(trend.from.date)+'</span>' : '')+
      (stale.stale ? '<span class="stalebadge" title="Pesquisa mais recente cadastrada há '+stale.days+' dias">'+icon('clock')+' dado desatualizado ('+stale.days+' dias)</span>' : '')+
    '</div>'
  ) : '';
  const compareBlock = base ? (
    '<div class="compare2022">'+
      '<div class="c22-row"><span>2022 — Lula</span><b>'+base.lula.toFixed(2)+'%</b></div>'+
      '<div class="c22-row"><span>2022 — Bolsonaro (pai)</span><b>'+base.bolsonaro.toFixed(2)+'%</b></div>'+
      (avg.has ? '<div class="c22-row highlight"><span>Variação de Lula em relação a 2022</span><span class="ppbadge '+ppClass(delta)+'">'+ppArrow(delta)+' '+fmtPP(delta)+'</span></div>'
               : '<div class="c22-row muted"><span>Sem pesquisas para calcular a variação ainda</span></div>')+
    '</div>'
  ) : '';
  document.getElementById('panel').innerHTML =
    '<h2>'+NAMES[uf]+' <span class="sub" style="font-weight:400;">('+uf+')</span></h2>'+
    '<div class="sub">Peso no total nacional (2022): '+(DATA[uf].weight*100).toFixed(1)+'% · Região: '+REGION_OF[uf]+'</div>'+
    '<div class="avg">'+avgLine+'</div>'+
    badgeRow+
    compareBlock+
    (polls.length ? '<div class="table-scroll"><table><thead><tr><th>Instituto</th><th>Data</th><th>Lula</th><th>Flávio</th><th>Cred.</th><th>Peso</th><th></th></tr></thead><tbody>'+rows+'</tbody></table></div>' : '')+
    '<button id="openAddBtn" type="button">'+icon('add')+' Adicionar pesquisa</button>';
  document.querySelectorAll('.ic.rm').forEach(b=>b.addEventListener('click', async e=>{
    const i=parseInt(e.target.closest('button').dataset.i);
    try{ await removePoll(uf, i); if(editingIndex===i) closePollModal(); await refresh(); }catch(err){ alert('Erro ao remover: '+err.message); }
  }));
  document.querySelectorAll('.ic.ed').forEach(b=>b.addEventListener('click', e=>{
    openPollModal(uf, parseInt(e.target.closest('button').dataset.i));
  }));
  document.getElementById('openAddBtn').addEventListener('click', ()=> openPollModal(uf, null));
}

/* ---------- Modal de adicionar/editar pesquisa --------------------------
   O formulário só existe dentro do modal agora — nunca mais empurra o
   mapa pra baixo. A mesma marcação de antes, só que gerada à parte e
   injetada em #modalBody quando o modal abre. */
function pollFormHTML(uf, editing){
  return (editing ? '<div class="full editnotice">'+icon('edit')+' Editando pesquisa de "'+editing.inst+'" — altere os campos e salve.</div>' : '')+
    '<div class="full"><label>Instituto de pesquisa</label><input id="f-inst" placeholder="Ex: Datafolha" value="'+(editing?editing.inst:'')+'"></div>'+
    '<div class="full"><label>Data da pesquisa</label><input id="f-date" type="date" value="'+(editing?editing.date:todayISO())+'"></div>'+
    '<div><label>Lula %</label><input id="f-lula" type="number" step="0.1" min="0" max="100" value="'+(editing?editing.lula:'')+'"></div>'+
    '<div><label>Flávio % (auto = 100-Lula)</label><input id="f-opp" type="number" step="0.1" min="0" max="100" placeholder="opcional" value="'+(editing?editing.opp:'')+'"></div>'+
    '<div class="full"><label>Credibilidade (1=baixa, 5=alta)</label><input id="f-cred" type="number" min="1" max="5" value="'+(editing?editing.cred:3)+'"></div>'+
    (editing
      ? '<button id="addbtn" class="full">'+icon('save')+' Salvar alterações</button><button id="cancelbtn" class="full ghost" type="button">Cancelar</button>'
      : '<button id="addbtn" class="full">'+icon('add')+' Adicionar pesquisa</button>');
}
function openPollModal(uf, editIndex){
  editingIndex = editIndex;
  const editing = editIndex!==null ? (DATA[uf].polls||[])[editIndex] : null;
  document.getElementById('modalTitle').textContent = editing ? 'Editar pesquisa · '+NAMES[uf] : 'Adicionar pesquisa · '+NAMES[uf];
  document.getElementById('modalBody').innerHTML = '<div id="addform">'+pollFormHTML(uf, editing)+'</div>';
  document.getElementById('pollModalOverlay').hidden = false;
  document.body.classList.add('modal-open');
  const cancelbtn = document.getElementById('cancelbtn');
  if(cancelbtn) cancelbtn.addEventListener('click', closePollModal);
  document.getElementById('addbtn').addEventListener('click', async ()=>{
    const inst=document.getElementById('f-inst').value.trim()||'Pesquisa sem nome';
    const date=document.getElementById('f-date').value || todayISO();
    let lula=parseFloat(document.getElementById('f-lula').value);
    if(isNaN(lula)) return;
    let opp=parseFloat(document.getElementById('f-opp').value);
    let cred=parseInt(document.getElementById('f-cred').value)||3;
    const payload = {inst,date,lula,opp:isNaN(opp)?undefined:opp,cred};
    try{
      if(editingIndex!==null){ await editPoll(uf, editingIndex, payload); }
      else { await addPoll(uf, payload); }
      closePollModal();
      await refresh();
    }
    catch(err){ alert('Erro ao salvar: '+err.message); }
  });
  document.getElementById('f-inst').focus();
}
function closePollModal(){
  document.getElementById('pollModalOverlay').hidden = true;
  document.body.classList.remove('modal-open');
  editingIndex = null;
}
document.getElementById('modalClose').addEventListener('click', closePollModal);
document.getElementById('pollModalOverlay').addEventListener('click', e=>{
  if(e.target.id==='pollModalOverlay') closePollModal();
});
document.addEventListener('keydown', e=>{
  if(e.key==='Escape' && !document.getElementById('pollModalOverlay').hidden) closePollModal();
});

function selectTab(name){
  document.querySelectorAll('nav#tabs button').forEach(b=>b.classList.toggle('active', b.dataset.tab===name));
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  document.getElementById(name+'view').classList.add('active');
}
document.querySelectorAll('nav#tabs button').forEach(b=>b.addEventListener('click',()=>selectTab(b.dataset.tab)));
document.querySelectorAll('input[name=method]').forEach(r=>r.addEventListener('change',e=>{ method=e.target.value; renderAll(); }));
document.querySelectorAll('input[name=mapmode]').forEach(r=>r.addEventListener('change',e=>{ mapMode=e.target.value; renderMap(); }));

/* ---------- Botões "Baixar PNG" (mapa e gráfico de correlação) --------- */
function mapLegendForExport(){
  return mapMode==='variacao'
    ? [{color:'#8c6205', label:'Recuo de Lula vs 2022'}, {color:'#faf4e7', label:'Sem dados / estável'}, {color:'#2c6b46', label:'Avanço de Lula vs 2022'}]
    : [{color:'#31506a', label:'Flávio à frente'}, {color:'#faf4e7', label:'Sem dados / empate'}, {color:'#a3392c', label:'Lula à frente'}];
}
const dlMapBtn = document.getElementById('dlMap');
if(dlMapBtn) dlMapBtn.addEventListener('click', ()=>{
  const modeLabel = mapMode==='variacao' ? 'Variação vs 2022 (p.p.)' : 'Intenção de voto — média ponderada das pesquisas';
  exportChartPNG('brmap', 'mapa-eleitoral-brasil-'+mapMode+'-'+todayISO()+'.png', {
    button: dlMapBtn,
    title: 'Mapa Eleitoral do Brasil',
    subtitle: modeLabel+' · Lula × Flávio Bolsonaro',
    legend: mapLegendForExport(),
    bg: '#fffdf8'
  });
});
const dlCorrBtn = document.getElementById('dlCorr');
if(dlCorrBtn) dlCorrBtn.addEventListener('click', ()=>{
  const pts = correlationPoints();
  const r = pts.length>=2 ? pearsonCorrelation(pts.map(p=>p.x), pts.map(p=>p.y)) : null;
  exportChartPNG('corrSvg', 'correlacao-2022-vs-2026-'+todayISO()+'.png', {
    button: dlCorrBtn,
    title: 'Correlação: resultado oficial de 2022 × cenário atual (2026)',
    subtitle: r===null ? 'Dados insuficientes para calcular a correlação.' : 'Correlação de Pearson r = '+r.toFixed(3)+' · '+pts.length+' estado(s) com pesquisa cadastrada',
    legend: [{color:'#3c7a4f', label:'Avançou vs 2022'}, {color:'#af4c3a', label:'Recuou vs 2022'}],
    bg: '#fffdf8'
  });
});
document.getElementById('reset').addEventListener('click', async ()=>{
  if(confirm('Remover todas as pesquisas cadastradas de todos os estados? Essa ação não pode ser desfeita.')){
    try{ await resetAll(); selectedUF=null; document.getElementById('panel').innerHTML='<p class="empty">Clique em um estado no mapa para ver e adicionar pesquisas.</p>'; await refresh(); }
    catch(err){ alert('Erro ao limpar: '+err.message); }
  }
});

async function refresh(){
  DATA = await fetchStates();
  renderAll();
}

async function init(){
  buildSVG();
  buildWatermark();
  try{
    await refresh();
    setSync('on');
  }catch(err){
    setSync('err', 'Sem conexão com o servidor/MongoDB');
    console.error(err);
  }
}
init();
