// Módulo isolado e testável (navegador + Node). Sem dependências.
(function (root) {
  const DAY = 86400000;
  const toTime = (s) => new Date(s + 'T12:00:00Z').getTime();
  // Votos válidos: só converte votos totais; pesquisas já válidas não são reconvertidas.
  function validShares(p) {
    if (p.resultType === 'valid') return { l: p.lula, f: p.flavio };
    const s = p.lula + p.flavio;
    if (!(s > 0)) return null;
    return { l: (p.lula / s) * 100, f: (p.flavio / s) * 100 };
  }
  function validatePoll(p) {
    const err = [], warn = [];
    const num = (v) => v !== null && v !== undefined && v !== '' && !isNaN(Number(v));
    if (!p.institute || !String(p.institute).trim()) err.push('Informe o instituto.');
    ['lula', 'flavio'].forEach((k) => {
      if (!num(p[k])) err.push(`Informe o percentual de ${k === 'lula' ? 'Lula' : 'Flávio'}.`);
      else if (p[k] < 0 || p[k] > 100) err.push('Percentuais devem estar entre 0 e 100.');
    });
    ['blankNull', 'undecided', 'others'].forEach((k) => {
      if (num(p[k]) && (p[k] < 0 || p[k] > 100)) err.push('Percentuais devem estar entre 0 e 100.');
    });
    if (!/^\d{4}-\d{2}-\d{2}$/.test(p.fieldEnd || '') || isNaN(toTime(p.fieldEnd))) err.push('Data final do campo inválida.');
    if (p.fieldStart && p.fieldEnd && p.fieldStart > p.fieldEnd) err.push('A data final do campo é anterior à inicial.');
    if (!['valid', 'total'].includes(p.resultType)) err.push('Indique se os resultados são votos totais ou válidos.');
    if (p.sample !== null && p.sample !== undefined && p.sample !== '' && !(Number(p.sample) > 0)) err.push('Amostra deve ser positiva.');
    if (err.length === 0) {
      const sum = ['lula', 'flavio', 'blankNull', 'undecided', 'others'].reduce((a, k) => a + (num(p[k]) ? Number(p[k]) : 0), 0);
      if (p.resultType === 'valid' && Math.abs(Number(p.lula) + Number(p.flavio) - 100) > 1.5) warn.push('Em votos válidos, Lula + Flávio deveria somar ~100%.');
      if (p.resultType === 'total' && sum > 101.5) warn.push('A soma dos percentuais passa de 100%.');
      if (!num(p.sample) && !num(p.moe)) warn.push('Sem amostra nem margem de erro: a pesquisa terá peso mínimo de precisão.');
    }
    return { errors: err, warnings: warn };
  }
  // Amostra efetiva: declarada; senão inferida da MoE (95%, p=0,5, amostragem aleatória simples).
  function effectiveN(p) {
    if (Number(p.sample) > 0) return Number(p.sample);
    if (Number(p.moe) > 0) return (1.96 * 1.96 * 0.25) / Math.pow(Number(p.moe) / 100, 2);
    return null;
  }
  // Peso = recência (decaimento exponencial) × precisão (∝ n, teto 5000); duplicadas excluídas.
  function weigh(p, refDate, opt) {
    const age = Math.max(0, (toTime(refDate) - toTime(p.fieldEnd)) / DAY);
    const f = [];
    if (p.duplicateOf) return { w: 0, included: false, reason: 'Duplicata de outro levantamento', age, factors: f };
    const sh = validShares(p);
    if (!sh) return { w: 0, included: false, reason: 'Resultados inválidos', age, factors: f };
    if (opt.windowDays && age > opt.windowDays) return { w: 0, included: false, reason: 'Fora do período', age, factors: f };
    if (opt.scope !== 'all' && p.scope !== opt.scope) return { w: 0, included: false, reason: 'Abrangência diferente', age, factors: f };
    const rec = Math.pow(0.5, age / opt.halfLife);
    const n = effectiveN(p);
    const prec = n ? Math.min(n, 5000) / 1000 : 0.25;
    f.push(`recência ${rec.toFixed(2)}`, n ? `precisão ${prec.toFixed(2)} (n≈${Math.round(n)})` : 'precisão mínima (sem n/MoE)');
    return { w: rec * prec, included: true, reason: '', age, factors: f };
  }
  function aggregate(polls, refDate, opt) {
    let sw = 0, sl = 0, sf = 0, c = 0, ul = 0, uf = 0;
    const info = {};
    polls.forEach((p) => {
      const r = weigh(p, refDate, opt);
      info[p.id] = r;
      if (r.included) { const s = validShares(p); sw += r.w; sl += r.w * s.l; sf += r.w * s.f; ul += s.l; uf += s.f; c++; }
    });
    return { info, count: c, weighted: c ? { l: sl / sw, f: sf / sw } : null, simple: c ? { l: ul / c, f: uf / c } : null };
  }
  // LOESS (grau 1 ou 2, kernel tricúbico, span = fração dos pontos). Retorna null se dados insuficientes.
  function loess(xs, ys, span, degree) {
    degree = degree || 1;
    const n = xs.length;
    if (n < 4 || new Set(xs).size < 3) return null;
    const q = Math.min(n, Math.max(degree + 2, Math.ceil(span * n)));
    return function (x0) {
      const d = xs.map((x) => Math.abs(x - x0)), sorted = d.slice().sort((a, b) => a - b);
      let h = sorted[q - 1];
      if (h <= 0) h = 1;
      const w = d.map((di) => (di < h ? Math.pow(1 - Math.pow(di / h, 3), 3) : 0));
      const t = xs.map((x) => (x - x0) / DAY);
      const m = degree + 1, A = Array.from({ length: m }, () => new Array(m + 1).fill(0));
      for (let i = 0; i < n; i++) {
        if (!w[i]) continue;
        for (let r = 0; r < m; r++) {
          for (let c = 0; c < m; c++) A[r][c] += w[i] * Math.pow(t[i], r + c);
          A[r][m] += w[i] * Math.pow(t[i], r) * ys[i];
        }
      }
      for (let r = 1; r < m; r++) A[r][r] += 1e-9 * (A[r][r] || 1);
      for (let i = 0; i < m; i++) {
        let p = i;
        for (let r = i + 1; r < m; r++) if (Math.abs(A[r][i]) > Math.abs(A[p][i])) p = r;
        [A[i], A[p]] = [A[p], A[i]];
        if (Math.abs(A[i][i]) < 1e-12) return A[0][0] > 0 ? A[0][m] / A[0][0] : null;
        for (let r = i + 1; r < m; r++) { const k = A[r][i] / A[i][i]; for (let c = i; c <= m; c++) A[r][c] -= k * A[i][c]; }
      }
      const b = new Array(m).fill(0);
      for (let i = m - 1; i >= 0; i--) { let s = A[i][m]; for (let c = i + 1; c < m; c++) s -= A[i][c] * b[c]; b[i] = s / A[i][i]; }
      return b[0]; // valor ajustado em x0
    };
  }
  root.Stats = { toTime, validShares, validatePoll, effectiveN, weigh, aggregate, loess, DAY };
  if (typeof module !== 'undefined') module.exports = root.Stats;
})(typeof window !== 'undefined' ? window : globalThis);
